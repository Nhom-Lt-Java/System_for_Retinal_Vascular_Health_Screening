# Suggested layout
data/
  DRIVE/images   DRIVE/masks
  STARE/images   STARE/masks
  CHASE_DB1/images  CHASE_DB1/masks
  HRF/images     HRF/masks
  FIVES/images   FIVES/masks
